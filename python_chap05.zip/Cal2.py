#-*-coding:utf-8

class Calculator:
    def plus(self, first, second):
        return first + second
    def minus(self, first, second):
        return first - second
    def multi(self, first, second):
        return first * second
    def divide(self, first, second):
        return first / second