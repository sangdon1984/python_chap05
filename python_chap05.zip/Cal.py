#-*-coding:utf-8

def plus(first, second):
    return first + second
def minus(first, second):
    return first - second
def multi(first, second):
    return first * second
def divide(first, second):
    return first / second